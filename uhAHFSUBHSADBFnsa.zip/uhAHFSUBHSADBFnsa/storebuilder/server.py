"""
server.py — UsahaKu Flask Server
Responsibilities:
  - Serves static frontend files
  - Loads all API keys from .env (keys NEVER reach the browser)
  - /api/config  → exposes Firebase public config to the browser
  - /api/gemini  → proxies Gemini API calls (Gemini key stays server-side)
"""

import os
import requests as req_lib
from flask import Flask, jsonify, request, send_from_directory
from dotenv import load_dotenv

# ── Load .env before anything else ──────────────────────────────────────────
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), ".env"))

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__, static_folder=BASE_DIR, static_url_path="")

# ── Gemini proxy constants ───────────────────────────────────────────────────
GEMINI_MODEL = "gemini-3.1-flash-lite"
GEMINI_BASE  = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
# No hardcoded placeholder — .env is the single source of truth.


# ── Routes ───────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    """Serve the SPA shell."""
    return send_from_directory(BASE_DIR, "index.html")


@app.route("/api/config")
def api_config():
    """
    Return Firebase public config to the browser.
    Firebase config values are designed to be public (they are in every
    web app's bundle). Only the Gemini key must stay server-side.
    """
    firebase_cfg = {
        "apiKey":            os.getenv("FIREBASE_API_KEY", ""),
        "authDomain":        os.getenv("FIREBASE_AUTH_DOMAIN", ""),
        "projectId":         os.getenv("FIREBASE_PROJECT_ID", ""),
        "storageBucket":     os.getenv("FIREBASE_STORAGE_BUCKET", ""),
        "messagingSenderId": os.getenv("FIREBASE_MESSAGING_SENDER_ID", ""),
        "appId":             os.getenv("FIREBASE_APP_ID", ""),
    }

    # Warn if Firebase not configured yet
    firebase_ready = bool(firebase_cfg["projectId"] and firebase_cfg["projectId"] != "YOUR_PROJECT_ID_HERE")

    return jsonify({
        "firebase": firebase_cfg,
        "firebaseReady": firebase_ready,
    })


@app.route("/api/gemini", methods=["POST"])
def api_gemini():
    """
    Server-side proxy for Gemini API.
    The browser sends the prompt body; this function adds the secret key
    and forwards the request to Google. The key never leaves the server.
    """
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        return jsonify({"error": "GEMINI_API_KEY not set in .env"}), 500

    body = request.get_json(force=True)
    if not body:
        return jsonify({"error": "Request body must be JSON"}), 400

    try:
        resp = req_lib.post(
            f"{GEMINI_BASE}?key={key}",
            json=body,
            timeout=30,
            headers={"Content-Type": "application/json"},
        )
        return jsonify(resp.json()), resp.status_code
    except req_lib.exceptions.Timeout:
        return jsonify({"error": "Gemini API timed out"}), 504
    except req_lib.exceptions.RequestException as exc:
        return jsonify({"error": str(exc)}), 502


@app.route("/<path:path>")
def static_files(path):
    """Serve any other static file."""
    return send_from_directory(BASE_DIR, path)


# ── Entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    gemini_ok   = bool(os.getenv("GEMINI_API_KEY", "").strip())
    firebase_ok = bool(os.getenv("FIREBASE_PROJECT_ID", "").strip())

    print("\n" + "=" * 54)
    print("  UsahaKu  ->  http://localhost:5000")
    print("=" * 54)
    print(f"  Gemini key : {'[SET]' if gemini_ok else '[NOT SET — edit .env]'}")
    print(f"  Firebase   : {'[SET]' if firebase_ok else '[NOT SET — edit .env]'}")
    print("=" * 54 + "\n")

    app.run(debug=True, port=5000, use_reloader=False)
