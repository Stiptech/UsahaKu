// templates/laporan-sederhana.js
// Returns a self-contained seller-only dashboard with a clean white minimalist layout in Indonesian.

function laporanSederhanaTemplate(d) {
  const storeName   = d.storeName   || "Toko Saya";
  const tagline     = d.tagline     || "Dashboard Seller";
  const primary     = d.primaryColor  || "#111827"; // Off-black
  const accent      = d.accentColor   || "#10B981"; // Emerald green
  const products    = Array.isArray(d.products) ? d.products : [];
  const logoUrl     = d.logoDataUrl   || "";
  const phone       = d.contact?.phone   || "";
  const email       = d.contact?.email   || "";
  const address     = d.contact?.address || "";
  const instagram   = d.social?.instagram || "";
  const whatsapp    = d.social?.whatsapp  || "";
  const tiktok      = d.social?.tiktok    || "";

  // Initials avatar fallback
  const initials = storeName.split(" ").slice(0, 2).map(w => w[0]?.toUpperCase() || "").join("");
  const logoHTML = logoUrl
    ? `<img src="${logoUrl}" alt="${storeName} logo" class="nav-logo-img">`
    : `<div class="nav-logo-initials" style="background:${primary}">${initials}</div>`;

  return `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Laporan Sederhana - ${esc(storeName)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Outfit:wght@500;600;700&display=swap" rel="stylesheet">
<style>
/* ── Design System & Theme ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
:root {
  --primary: ${primary};
  --accent: ${accent};
  --bg: #FAFAFA;
  --surface: #FFFFFF;
  --text: #171717;
  --text-muted: #737373;
  --border: #E5E5E5;
  --radius: 8px;
  --shadow: 0 1px 3px rgba(0,0,0,0.05), 0 1px 2px rgba(0,0,0,0.02);
}
body {
  font-family: 'Inter', sans-serif;
  background-color: var(--bg);
  color: var(--text);
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* ── Minimal Navbar ── */
header {
  background-color: var(--surface);
  border-bottom: 1px solid var(--border);
  padding: 16px 40px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 50;
}
.brand {
  display: flex;
  align-items: center;
  gap: 12px;
}
.nav-logo-img {
  width: 36px;
  height: 36px;
  border-radius: 6px;
  object-fit: cover;
}
.nav-logo-initials {
  width: 36px;
  height: 36px;
  border-radius: 6px;
  display: grid;
  place-items: center;
  font-family: 'Outfit', sans-serif;
  font-size: 14px;
  font-weight: 700;
  color: #FFFFFF;
}
.brand-name {
  font-family: 'Outfit', sans-serif;
  font-weight: 700;
  font-size: 1.15rem;
  letter-spacing: -0.3px;
}
.nav-links {
  display: flex;
  gap: 24px;
}
.nav-link {
  font-size: 0.875rem;
  font-weight: 500;
  color: var(--text-muted);
  text-decoration: none;
  padding: 8px 0;
  border-bottom: 2px solid transparent;
  transition: all 0.2s ease;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 6px;
}
.nav-link:hover {
  color: var(--text);
}
.nav-link.active {
  color: var(--text);
  font-weight: 600;
  border-bottom-color: var(--accent);
}

/* Mobile Hamburger */
.hamburger {
  display: none;
  background: none;
  border: none;
  color: var(--text);
  font-size: 1.3rem;
  cursor: pointer;
}

/* ── Container ── */
.container {
  max-width: 1000px;
  width: 100%;
  margin: 0 auto;
  padding: 32px 24px;
  flex: 1;
}

/* ── Page Views ── */
.page { display: none; animation: fadeIn 0.2s ease both; }
.page.active { display: block; }

/* ── Typography & Cards ── */
.page-title {
  font-family: 'Outfit', sans-serif;
  font-size: 1.6rem;
  font-weight: 700;
  margin-bottom: 4px;
  letter-spacing: -0.2px;
}
.page-subtitle {
  font-size: 0.85rem;
  color: var(--text-muted);
  margin-bottom: 24px;
}

.card {
  background-color: var(--surface);
  border-radius: var(--radius);
  border: 1px solid var(--border);
  box-shadow: var(--shadow);
  margin-bottom: 24px;
}
.card-header {
  padding: 16px 20px;
  border-bottom: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.card-title { font-size: 0.875rem; font-weight: 600; color: var(--text); text-transform: uppercase; letter-spacing: 0.5px; }
.card-content { padding: 20px; }

/* ── Forms ── */
.form-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: flex-end;
}
.form-group {
  display: flex;
  flex-direction: column;
  gap: 4px;
  flex: 1;
  min-width: 140px;
}
.form-group label {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--text-muted);
}
.form-group input, .form-group select {
  padding: 8px 12px;
  border: 1px solid var(--border);
  border-radius: 6px;
  font-size: 0.85rem;
  font-family: inherit;
  outline: none;
  background-color: #FFFFFF;
  transition: border-color 0.2s ease;
}
.form-group input:focus, .form-group select:focus {
  border-color: var(--accent);
}
.btn {
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 0.85rem;
  font-weight: 600;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
}
.btn-primary {
  background-color: var(--primary);
  color: #FFFFFF;
}
.btn-primary:hover {
  opacity: 0.9;
}
.btn-danger-outline {
  background: transparent;
  border: 1px solid #EF4444;
  color: #EF4444;
}
.btn-danger-outline:hover {
  background-color: #EF4444;
  color: #FFFFFF;
}

/* ── Tables ── */
.table-container {
  overflow-x: auto;
}
table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
}
th {
  padding: 12px 16px;
  font-size: 0.72rem;
  font-weight: 600;
  text-transform: uppercase;
  color: var(--text-muted);
  background-color: #FAFADA; /* Warm tint */
  background-color: #FAFAFA;
  border-bottom: 1px solid var(--border);
  letter-spacing: 0.5px;
}
td {
  padding: 14px 16px;
  font-size: 0.85rem;
  border-bottom: 1px solid var(--border);
  vertical-align: middle;
}
tr:last-child td { border-bottom: none; }
tr:hover td { background-color: #FAFAFA; }

/* Status Badges */
.badge {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 0.72rem;
  font-weight: 600;
  border: 1px solid transparent;
}
.badge-menunggu { background-color: #FEF3C7; color: #D97706; border-color: #FBE5C6; }
.badge-diproses { background-color: #DBEAFE; color: #2563EB; border-color: #C3DAFD; }
.badge-dikirim  { background-color: #F3E8FF; color: #7C3AED; border-color: #E8D3FF; }
.badge-selesai  { background-color: #D1FAE5; color: #059669; border-color: #A7F3D0; }

/* Stats */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
  margin-bottom: 24px;
}
.stat-card {
  background-color: var(--surface);
  border-radius: var(--radius);
  border: 1px solid var(--border);
  padding: 16px 20px;
}
.stat-label {
  font-size: 0.72rem;
  font-weight: 600;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.stat-value {
  font-family: 'Outfit', sans-serif;
  font-size: 1.35rem;
  font-weight: 600;
  color: var(--text);
  margin-top: 4px;
}

/* Warnings */
.low-stock { background-color: #FFF5F5; }
.low-stock td:nth-child(3) { color: #EF4444; font-weight: 700; }

/* ── Animation ── */
@keyframes fadeIn {
  from { opacity: 0; transform: translateY(4px); }
  to { opacity: 1; transform: translateY(0); }
}

/* ── Responsive ── */
@media (max-width: 768px) {
  header {
    padding: 16px 20px;
  }
  .nav-links {
    display: none;
    position: absolute;
    top: 68px;
    left: 0;
    right: 0;
    background-color: var(--surface);
    flex-direction: column;
    padding: 16px 20px;
    border-bottom: 1px solid var(--border);
    box-shadow: var(--shadow);
  }
  .nav-links.open {
    display: flex;
  }
  .nav-link {
    width: 100%;
    padding: 10px 0;
  }
  .hamburger {
    display: block;
  }
  .container {
    padding: 20px 16px;
  }
  .form-grid {
    flex-direction: column;
    align-items: stretch;
  }
  .form-group {
    width: 100%;
  }
}
</style>
</head>
<body>

<!-- HEADER -->
<header>
  <div class="brand">
    ${logoHTML}
    <span class="brand-name">${esc(storeName)}</span>
  </div>
  <nav class="nav-links" id="nav-links">
    <a class="nav-link active" data-page="orders" onclick="showPage('orders', this)">Pesanan</a>
    <a class="nav-link" data-page="stock" onclick="showPage('stock', this)">Produk</a>
    <a class="nav-link" data-page="accounting" onclick="showPage('accounting', this)">Keuangan</a>
  </nav>
  <button class="hamburger" onclick="toggleMenu()">☰</button>
</header>

<div class="container">

  <!-- ══ PAGE: ORDERS ══ -->
  <div class="page active" id="page-orders">
    <h1 class="page-title">Daftar Pesanan</h1>
    <p class="page-subtitle">Status transaksi pesanan masuk secara real-time.</p>

    <!-- Form Order -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Tambah Pesanan</h3>
      </div>
      <div class="card-content">
        <div class="form-grid">
          <div class="form-group">
            <label>Nama Pelanggan</label>
            <input id="o-customer" type="text" placeholder="Nama Pembeli">
          </div>
          <div class="form-group">
            <label>Produk</label>
            <select id="o-product">
              <!-- JS -->
            </select>
          </div>
          <div class="form-group" style="max-width: 100px;">
            <label>Jumlah (Qty)</label>
            <input id="o-qty" type="number" value="1" min="1">
          </div>
          <div class="form-group">
            <label>Status</label>
            <select id="o-status">
              <option value="Menunggu">Menunggu</option>
              <option value="Diproses">Diproses</option>
              <option value="Dikirim">Dikirim</option>
              <option value="Selesai">Selesai</option>
            </select>
          </div>
          <button class="btn btn-primary" onclick="addOrder()">Simpan</button>
        </div>
      </div>
    </div>

    <!-- Tabel -->
    <div class="card">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Pelanggan</th>
              <th>Produk</th>
              <th>Qty</th>
              <th>Status</th>
              <th>Tanggal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="orders-tbody">
            <!-- JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ══ PAGE: STOCK ══ -->
  <div class="page" id="page-stock">
    <h1 class="page-title">Inventaris Barang</h1>
    <p class="page-subtitle">Daftar stok produk dan notifikasi batas minimum.</p>

    <!-- Form -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Produk Baru</h3>
      </div>
      <div class="card-content">
        <div class="form-grid">
          <div class="form-group">
            <label>Nama Produk</label>
            <input id="s-name" type="text" placeholder="Nama produk">
          </div>
          <div class="form-group">
            <label>SKU (Opsional)</label>
            <input id="s-sku" type="text" placeholder="SKU-101">
          </div>
          <div class="form-group" style="max-width: 100px;">
            <label>Stok Awal</label>
            <input id="s-qty" type="number" value="10" min="0">
          </div>
          <div class="form-group">
            <label>Harga Jual</label>
            <input id="s-price" type="text" placeholder="Rp 100.000">
          </div>
          <div class="form-group" style="max-width: 100px;">
            <label>Batas Minim</label>
            <input id="s-threshold" type="number" value="3" min="0">
          </div>
          <button class="btn btn-primary" onclick="addStockItem()">Simpan</button>
        </div>
      </div>
    </div>

    <!-- Tabel -->
    <div class="card">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Nama Produk</th>
              <th>SKU</th>
              <th>Stok</th>
              <th>Harga Jual</th>
              <th>Batas Minim</th>
              <th>Diupdate</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="stock-tbody">
            <!-- JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- ══ PAGE: ACCOUNTING ══ -->
  <div class="page" id="page-accounting">
    <h1 class="page-title">Buku Keuangan</h1>
    <p class="page-subtitle">Laporan neraca keuangan, pemasukan, dan pengeluaran.</p>

    <!-- Stats -->
    <div class="stats-grid">
      <div class="stat-card">
        <span class="stat-label">Saldo Bersih</span>
        <div class="stat-value" id="bal-balance">Rp 0</div>
      </div>
      <div class="stat-card" style="border-left: 3px solid #10B981;">
        <span class="stat-label">Pemasukan</span>
        <div class="stat-value" style="color:#10B981" id="bal-income">Rp 0</div>
      </div>
      <div class="stat-card" style="border-left: 3px solid #EF4444;">
        <span class="stat-label">Pengeluaran</span>
        <div class="stat-value" style="color:#EF4444" id="bal-expense">Rp 0</div>
      </div>
    </div>

    <!-- Form -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Catat Transaksi</h3>
      </div>
      <div class="card-content">
        <div class="form-grid">
          <div class="form-group">
            <label>Keterangan</label>
            <input id="a-desc" type="text" placeholder="Keterangan transaksi">
          </div>
          <div class="form-group" style="max-width: 150px;">
            <label>Tipe</label>
            <select id="a-type">
              <option value="Income">Pemasukan</option>
              <option value="Expense">Pengeluaran</option>
            </select>
          </div>
          <div class="form-group">
            <label>Nominal (Angka)</label>
            <input id="a-amount" type="number" placeholder="50000" min="0">
          </div>
          <div class="form-group" style="max-width: 180px;">
            <label>Tanggal</label>
            <input id="a-date" type="date">
          </div>
          <button class="btn btn-primary" onclick="addTransaction()">Simpan</button>
        </div>
      </div>
    </div>

    <!-- Chart -->
    <div class="card">
      <div class="card-header">
        <h3 class="card-title">Visualisasi Cashflow Bulanan</h3>
      </div>
      <div class="card-content">
        <canvas id="accounting-chart-canvas" height="180"></canvas>
      </div>
    </div>

    <!-- Tabel -->
    <div class="card">
      <div class="table-container">
        <table>
          <thead>
            <tr>
              <th>Tanggal</th>
              <th>Keterangan</th>
              <th>Tipe</th>
              <th>Nominal</th>
              <th>Aksi</th>
            </tr>
          </thead>
          <tbody id="acc-tbody">
            <!-- JS -->
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<script>
// ── Utilities ──
function $(id) { return document.getElementById(id); }
function fmt(n) { return 'Rp ' + Number(n).toLocaleString('id-ID'); }
function today() { return new Date().toISOString().slice(0, 10); }
function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
function esc2(s) { const d = document.createElement('div'); d.textContent = String(s || ''); return d.innerHTML; }

// ── Navigation ──
function showPage(name, el) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(a => a.classList.remove('active'));
  $('page-' + name).classList.add('active');
  if (el) el.classList.add('active');
  
  // Close menu on mobile
  $('nav-links').classList.remove('open');

  if (name === 'accounting') {
    renderChart();
  }
}
function toggleMenu() {
  $('nav-links').classList.toggle('open');
}

// ── Prepopulation Stock Setup ──
const initialProducts = ${JSON.stringify(products)};

function initStock() {
  const stock = getStock();
  if (stock.length === 0 && initialProducts.length > 0) {
    const defaultStock = initialProducts.map((p, i) => ({
      id: uid() + '-' + i,
      name: p.name,
      sku: p.sku || 'SKU-' + (1000 + i),
      qty: 15,
      price: p.price || 'Rp 0',
      threshold: 3,
      updated: today()
    }));
    saveStock(defaultStock);
  }
}

// ── Orders ──
function getOrders() { try { return JSON.parse(localStorage.getItem('storebuilder_orders') || '[]'); } catch(e) { return []; } }
function saveOrders(o) { localStorage.setItem('storebuilder_orders', JSON.stringify(o)); }

function addOrder() {
  const customer = $('o-customer').value.trim();
  const product = $('o-product').value;
  const qty = parseInt($('o-qty').value) || 1;
  const status = $('o-status').value;
  if (!customer || !product) { alert('Harap isi nama pelanggan dan pilih produk.'); return; }
  
  const orders = getOrders();
  orders.unshift({ id: uid(), customer, product, qty, status, date: today() });
  saveOrders(orders);
  $('o-customer').value = '';
  $('o-qty').value = 1;
  
  // Deduct stock
  const stock = getStock();
  const stockItem = stock.find(s => s.name === product);
  if (stockItem) {
    stockItem.qty = Math.max(0, stockItem.qty - qty);
    stockItem.updated = today();
    saveStock(stock);
    renderStock();
  }

  // Automatic income entry
  if (status === 'Selesai' && stockItem) {
    const priceNum = parseFloat(stockItem.price.replace(/[^0-9,-]+/g,"")) || 0;
    if (priceNum > 0) {
      const acc = getAcc();
      acc.unshift({
        id: uid(),
        desc: 'Pesanan #' + customer,
        type: 'Income',
        amount: priceNum * qty,
        date: today()
      });
      saveAcc(acc);
      renderAcc();
    }
  }

  renderOrders();
}

function updateOrderStatus(id, status) {
  const oldOrders = getOrders();
  const order = oldOrders.find(o => o.id === id);
  if (!order) return;

  const oldStatus = order.status;
  const orders = oldOrders.map(o => o.id === id ? { ...o, status } : o);
  saveOrders(orders);
  
  if (status === 'Selesai' && oldStatus !== 'Selesai') {
    const stock = getStock();
    const stockItem = stock.find(s => s.name === order.product);
    if (stockItem) {
      const priceNum = parseFloat(stockItem.price.replace(/[^0-9,-]+/g,"")) || 0;
      if (priceNum > 0) {
        const acc = getAcc();
        acc.unshift({
          id: uid(),
          desc: 'Penyelesaian Pesanan #' + order.customer,
          type: 'Income',
          amount: priceNum * order.qty,
          date: today()
        });
        saveAcc(acc);
        renderAcc();
      }
    }
  }

  renderOrders();
}

function deleteOrder(id) {
  if (!confirm('Hapus pesanan ini?')) return;
  saveOrders(getOrders().filter(o => o.id !== id));
  renderOrders();
}

function renderOrders() {
  const orders = getOrders();
  const tbody = $('orders-tbody');
  if (!orders.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);font-style:italic;padding:40px;">Belum ada pesanan masuk.</td></tr>';
    return;
  }
  tbody.innerHTML = orders.map(o => \`
    <tr>
      <td><code style="font-size:0.75rem;color:var(--text-muted)">\${o.id.slice(0,6)}</code></td>
      <td><strong>\${esc2(o.customer)}</strong></td>
      <td>\${esc2(o.product)}</td>
      <td>\${o.qty}</td>
      <td>
        <select class="badge badge-\${o.status.toLowerCase()}" onchange="updateOrderStatus('\${o.id}', this.value)" style="border:none;background:transparent;cursor:pointer;font-family:inherit;color:inherit;">
          \${['Menunggu','Diproses','Dikirim','Selesai'].map(s => \`<option \${s===o.status?'selected':''} value="\${s}">\${s}</option>\`).join('')}
        </select>
      </td>
      <td>\${o.date}</td>
      <td><button class="btn btn-danger-outline btn-sm" onclick="deleteOrder('\${o.id}')" style="padding:4px 8px;font-size:0.75rem">Hapus</button></td>
    </tr>\`).join('');
}

// ── Stock ──
function getStock() { try { return JSON.parse(localStorage.getItem('storebuilder_stock') || '[]'); } catch(e) { return []; } }
function saveStock(s) {
  localStorage.setItem('storebuilder_stock', JSON.stringify(s));
  updateProductDropdown();
}

function updateProductDropdown() {
  const dropdown = $('o-product');
  if (!dropdown) return;
  const stock = getStock();
  if (stock.length === 0) {
    dropdown.innerHTML = '<option value="">(Tidak ada produk)</option>';
    return;
  }
  dropdown.innerHTML = stock.map(s => \`<option value="\${esc2(s.name)}">\${esc2(s.name)} (\${s.price})</option>\`).join('');
}

function addStockItem() {
  const name = $('s-name').value.trim();
  const price = $('s-price').value.trim();
  if (!name || !price) { alert('Nama produk dan harga wajib diisi.'); return; }
  
  const item = {
    id: uid(),
    name,
    sku: $('s-sku').value.trim() || ('SKU-' + Date.now().toString().slice(-4)),
    qty: parseInt($('s-qty').value) || 0,
    price,
    threshold: parseInt($('s-threshold').value) || 3,
    updated: today()
  };
  
  const stock = getStock();
  stock.unshift(item);
  saveStock(stock);
  
  $('s-name').value = '';
  $('s-sku').value = '';
  $('s-qty').value = 10;
  $('s-price').value = '';
  renderStock();
}

function deleteStockItem(id) {
  if (!confirm('Hapus produk ini dari toko?')) return;
  saveStock(getStock().filter(s => s.id !== id));
  renderStock();
}

function editStockQty(id) {
  const item = getStock().find(s => s.id === id);
  if (!item) return;
  const newQty = prompt('Masukkan jumlah stok baru untuk ' + item.name + ':', item.qty);
  if (newQty === null) return;
  const qty = parseInt(newQty);
  if (isNaN(qty) || qty < 0) { alert('Masukkan jumlah angka stok yang valid.'); return; }
  
  saveStock(getStock().map(s => s.id === id ? { ...s, qty, updated: today() } : s));
  renderStock();
}

function renderStock() {
  const stock = getStock();
  const tbody = $('stock-tbody');
  if (!stock.length) {
    tbody.innerHTML = '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);font-style:italic;padding:40px;">Belum ada produk jualan.</td></tr>';
    return;
  }
  tbody.innerHTML = stock.map(s => \`
    <tr class="\${s.qty <= s.threshold ? 'low-stock' : ''}">
      <td><strong>\${esc2(s.name)}</strong></td>
      <td><code style="font-size:0.75rem">\${esc2(s.sku)}</code></td>
      <td>\${s.qty} \${s.qty <= s.threshold ? '<span style="color:#EF4444;font-size:0.75rem;margin-left:4px;">⚠️ Menipis</span>' : ''}</td>
      <td>\${esc2(s.price)}</td>
      <td>\${s.threshold} pcs</td>
      <td>\${s.updated}</td>
      <td>
        <div style="display:flex;gap:6px;">
          <button class="btn btn-primary" onclick="editStockQty('\${s.id}')" style="padding:4px 8px;font-size:0.75rem">Edit Stok</button>
          <button class="btn btn-danger-outline" onclick="deleteStockItem('\${s.id}')" style="padding:4px 8px;font-size:0.75rem">Hapus</button>
        </div>
      </td>
    </tr>\`).join('');
}

// ── Accounting ──
function getAcc() { try { return JSON.parse(localStorage.getItem('storebuilder_accounting') || '[]'); } catch(e) { return []; } }
function saveAcc(a) { localStorage.setItem('storebuilder_accounting', JSON.stringify(a)); }

function addTransaction() {
  const desc = $('a-desc').value.trim();
  const type = $('a-type').value;
  const amount = parseFloat($('a-amount').value);
  const date = $('a-date').value || today();
  if (!desc || isNaN(amount) || amount <= 0) { alert('Harap isi deskripsi dan jumlah nominal transaksi yang positif.'); return; }
  
  const acc = getAcc();
  acc.unshift({ id: uid(), desc, type, amount, date });
  saveAcc(acc);
  
  $('a-desc').value = '';
  $('a-amount').value = '';
  renderAcc();
  renderChart();
}

function deleteTransaction(id) {
  if (!confirm('Hapus catatan transaksi ini?')) return;
  saveAcc(getAcc().filter(a => a.id !== id));
  renderAcc();
  renderChart();
}

function renderAcc() {
  const acc = getAcc();
  let income = 0, expense = 0;
  acc.forEach(a => {
    if (a.type === 'Income') income += a.amount;
    else expense += a.amount;
  });
  $('bal-income').textContent = fmt(income);
  $('bal-expense').textContent = fmt(expense);
  $('bal-balance').textContent = fmt(income - expense);

  const tbody = $('acc-tbody');
  if (!acc.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:var(--text-muted);font-style:italic;padding:40px;">Belum ada catatan transaksi.</td></tr>';
    return;
  }
  tbody.innerHTML = acc.map(a => \`
    <tr>
      <td>\${a.date}</td>
      <td>\${esc2(a.desc)}</td>
      <td><span class="badge badge-\${a.type.toLowerCase()}">\${a.type === 'Income' ? 'Pemasukan' : 'Pengeluaran'}</span></td>
      <td style="font-weight:700;color:\${a.type==='Income'?'#10B981':'#EF4444'}">\${a.type==='Income'?'+':'-'}\${fmt(a.amount)}</td>
      <td><button class="btn btn-danger-outline btn-sm" onclick="deleteTransaction('\${a.id}')" style="padding:4px 8px;font-size:0.75rem">Hapus</button></td>
    </tr>\`).join('');
}

function renderChart() {
  const canvas = $('accounting-chart-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const acc = getAcc();

  // Group by YYYY-MM
  const monthly = {};
  acc.forEach(a => {
    const month = a.date.slice(0, 7);
    if (!monthly[month]) monthly[month] = { income: 0, expense: 0 };
    if (a.type === 'Income') monthly[month].income += a.amount;
    else monthly[month].expense += a.amount;
  });
  const keys = Object.keys(monthly).sort().slice(-6);

  const W = canvas.offsetWidth || 600;
  canvas.width = W; canvas.height = 180;
  ctx.clearRect(0, 0, W, 180);

  if (!keys.length) {
    ctx.fillStyle = '#737373';
    ctx.font = '13px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('Belum ada data keuangan untuk ditampilkan dalam grafik.', W/2, 90);
    return;
  }

  const maxVal = Math.max(...keys.flatMap(k => [monthly[k].income, monthly[k].expense]), 1);
  const pad = 40, barW = Math.min(30, (W - pad*2) / (keys.length * 2.5));
  const gap = (W - pad*2 - keys.length * barW * 2) / (keys.length + 1);
  const chartH = 130;

  keys.forEach((k, i) => {
    const x = pad + gap * (i+1) + i * barW * 2;
    const { income, expense } = monthly[k];

    // Income
    const ih = (income / maxVal) * chartH;
    ctx.fillStyle = '#10B981';
    ctx.beginPath();
    ctx.roundRect(x, chartH - ih + 15, barW, ih, [4, 4, 0, 0]);
    ctx.fill();

    // Expense
    const eh = (expense / maxVal) * chartH;
    ctx.fillStyle = '#EF4444';
    ctx.beginPath();
    ctx.roundRect(x + barW + 4, chartH - eh + 15, barW, eh, [4, 4, 0, 0]);
    ctx.fill();

    // Label
    ctx.fillStyle = '#737373';
    ctx.font = '10px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(k, x + barW + 2, 165);
  });

  // Legend
  ctx.fillStyle = '#10B981'; ctx.fillRect(W - 140, 4, 10, 10);
  ctx.fillStyle = '#171717'; ctx.font = '11px Inter, sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('Pemasukan', W - 125, 13);
  ctx.fillStyle = '#EF4444'; ctx.fillRect(W - 140, 20, 10, 10);
  ctx.fillStyle = '#171717'; ctx.fillText('Pengeluaran', W - 125, 29);
}

// ── Boot ──
(function() {
  $('a-date').value = today();
  initStock();
  updateProductDropdown();
  renderOrders();
  renderStock();
  renderAcc();
  window.addEventListener('resize', () => { if ($('page-accounting').classList.contains('active')) renderChart(); });
})();
</script>
</body>
</html>`;
}

// HTML escape helper
function esc(s) {
  return String(s || "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#39;");
}
