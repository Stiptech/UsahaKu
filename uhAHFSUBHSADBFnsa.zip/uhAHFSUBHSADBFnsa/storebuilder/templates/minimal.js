// templates/minimal.js
// Returns a complete self-contained HTML string for the generated store site.

function minimalTemplate(d) {
  const storeName   = d.storeName   || "My Store";
  const tagline     = d.tagline     || "Welcome to our store";
  const primary     = d.primaryColor  || "#2C3E50";
  const accent      = d.accentColor   || "#E67E22";
  const logoUrl     = d.logoDataUrl   || "";
  const products    = Array.isArray(d.products) ? d.products : [];
  const phone       = d.contact?.phone   || "";
  const email       = d.contact?.email   || "";
  const address     = d.contact?.address || "";
  const instagram   = d.social?.instagram || "";
  const whatsapp    = d.social?.whatsapp  || "";
  const tiktok      = d.social?.tiktok    || "";

  // Initials avatar fallback
  const initials = storeName.split(" ").slice(0,2).map(w => w[0]?.toUpperCase() || "").join("");

  // Logo HTML
  const logoHTML = logoUrl
    ? `<img src="${logoUrl}" alt="${storeName} logo" class="nav-logo-img">`
    : `<div class="nav-logo-initials">${initials}</div>`;

  // Product cards
  const productCards = products.length > 0
    ? products.map((p, i) => {
        const hue = (i * 47 + 200) % 360;
        return `
        <div class="product-card">
          <div class="product-img" style="background:hsl(${hue},55%,88%)">
            <span class="product-emoji">🛍️</span>
          </div>
          <div class="product-body">
            <h3 class="product-name">${esc(p.name || "Product")}</h3>
            ${p.price ? `<p class="product-price">${esc(p.price)}</p>` : ""}
            ${p.description ? `<p class="product-desc">${esc(p.description)}</p>` : ""}
            <button class="btn-order" onclick="openAddOrderPrefill('${esc(p.name || "Product")}')">Order Now</button>
          </div>
        </div>`;
      }).join("")
    : `<p class="no-products">No products listed yet. Add them in the Stock tab!</p>`;

  // Social links
  const socialLinks = [
    instagram ? `<a href="https://instagram.com/${instagram.replace("@","")}" target="_blank" class="social-link">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" width="20" height="20"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
      ${instagram}</a>` : "",
    whatsapp ? `<a href="https://wa.me/${whatsapp.replace(/\D/g,"")}" target="_blank" class="social-link">
      <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.77.46 3.43 1.27 4.87L2 22l5.3-1.24A9.94 9.94 0 0012 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm4.86 13.86c-.2.56-1.17 1.07-1.62 1.12-.44.05-.86.22-2.9-.6-2.44-1-3.98-3.46-4.1-3.62-.12-.16-.97-1.29-.97-2.46s.62-1.74.84-1.98c.22-.24.48-.3.64-.3h.46c.16 0 .37-.06.58.44.22.5.74 1.82.8 1.96.06.14.1.3.02.48-.08.18-.12.28-.24.44-.12.16-.25.35-.36.47-.12.12-.24.25-.1.5.14.24.62 1.02 1.32 1.65.91.82 1.67 1.07 1.91 1.19.24.12.38.1.52-.06.14-.16.6-.7.76-.94.16-.24.32-.2.54-.12.22.08 1.38.65 1.62.77.24.12.4.18.46.28.06.1.06.58-.14 1.14z"/></svg>
      ${whatsapp}</a>` : "",
    tiktok ? `<a href="https://tiktok.com/@${tiktok.replace("@","")}" target="_blank" class="social-link">
      <svg viewBox="0 0 24 24" fill="currentColor" width="20" height="20"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.28 6.28 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.75a8.18 8.18 0 004.78 1.52V6.79a4.85 4.85 0 01-1.01-.1z"/></svg>
      ${tiktok}</a>` : "",
  ].filter(Boolean).join("");

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${esc(storeName)}</title>
<meta name="description" content="${esc(tagline)}">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Poppins:wght@700;800&display=swap" rel="stylesheet">
<style>
/* ── Reset & Root ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --primary:${primary};
  --accent:${accent};
  --text:#1A1D2E;
  --muted:#6B7280;
  --bg:#F7F8FC;
  --surface:#FFFFFF;
  --border:#E5E7F0;
  --r:12px;
  --shadow:0 4px 16px rgba(0,0,0,0.08);
}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:var(--bg);color:var(--text);min-height:100vh}
h1,h2,h3,h4{font-family:'Poppins',sans-serif}
a{text-decoration:none;color:inherit}
button{font-family:'Inter',sans-serif;cursor:pointer}

/* ── Nav ── */
nav{
  position:sticky;top:0;z-index:100;
  display:flex;align-items:center;gap:12px;
  padding:12px 32px;
  background:rgba(255,255,255,0.92);
  backdrop-filter:blur(12px);
  border-bottom:1px solid var(--border);
  box-shadow:0 2px 12px rgba(0,0,0,0.06);
}
.nav-brand{display:flex;align-items:center;gap:10px;margin-right:auto}
.nav-logo-img{width:36px;height:36px;border-radius:8px;object-fit:cover}
.nav-logo-initials{
  width:36px;height:36px;border-radius:8px;
  background:var(--primary);color:#fff;
  display:grid;place-items:center;
  font-family:'Poppins',sans-serif;font-size:14px;font-weight:800;
}
.nav-store-name{font-family:'Poppins',sans-serif;font-size:1rem;font-weight:700;color:var(--text)}
.nav-links{display:flex;gap:6px;align-items:center}
.nav-link{
  padding:7px 14px;border-radius:999px;
  font-size:0.85rem;font-weight:500;color:var(--muted);
  transition:all .18s ease;border:1.5px solid transparent;
}
.nav-link:hover{color:var(--primary);background:rgba(0,0,0,0.04)}
.nav-link.active{color:#fff;background:var(--primary);border-color:var(--primary)}

/* Hamburger */
.hamburger{display:none;flex-direction:column;gap:5px;background:none;border:none;padding:4px;cursor:pointer}
.hamburger span{display:block;width:22px;height:2px;background:var(--text);border-radius:2px;transition:all .25s ease}
.hamburger.open span:nth-child(1){transform:rotate(45deg) translate(5px,5px)}
.hamburger.open span:nth-child(2){opacity:0}
.hamburger.open span:nth-child(3){transform:rotate(-45deg) translate(5px,-5px)}

.mobile-nav{
  display:none;flex-direction:column;gap:2px;
  position:absolute;top:60px;left:0;right:0;
  background:#fff;border-bottom:1px solid var(--border);
  padding:8px 16px 16px;box-shadow:var(--shadow);z-index:99;
}
.mobile-nav.open{display:flex}
.mobile-nav .nav-link{width:100%;text-align:left;border-radius:8px;padding:10px 14px}

/* ── Pages ── */
.page{display:none;animation:fadeIn .3s ease both}
.page.active{display:block}

/* ── Hero ── */
#page-home .hero{
  background:linear-gradient(135deg,var(--primary),color-mix(in srgb,var(--primary) 60%,#000));
  padding:80px 32px;text-align:center;color:#fff;
  position:relative;overflow:hidden;
}
#page-home .hero::before{
  content:'';position:absolute;inset:0;
  background:url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.04'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
}
#page-home .hero-logo{
  width:72px;height:72px;border-radius:16px;
  background:rgba(255,255,255,0.15);border:2px solid rgba(255,255,255,0.3);
  display:grid;place-items:center;margin:0 auto 20px;
  font-family:'Poppins',sans-serif;font-size:28px;font-weight:800;color:#fff;
  backdrop-filter:blur(4px);overflow:hidden;
}
#page-home .hero-logo img{width:100%;height:100%;object-fit:cover;border-radius:14px}
#page-home .hero h1{font-size:clamp(2rem,5vw,3rem);font-weight:800;letter-spacing:-1px;margin-bottom:12px;position:relative}
#page-home .hero p{font-size:1.1rem;opacity:0.85;max-width:480px;margin:0 auto 32px;line-height:1.6;position:relative}
.btn-accent{
  display:inline-flex;align-items:center;gap:8px;
  padding:13px 28px;background:var(--accent);color:#fff;
  border:none;border-radius:999px;font-size:0.95rem;font-weight:600;
  box-shadow:0 4px 16px rgba(0,0,0,0.25);
  transition:transform .18s ease,box-shadow .18s ease;
}
.btn-accent:hover{transform:translateY(-2px);box-shadow:0 8px 24px rgba(0,0,0,0.3)}

/* Products section */
.section{padding:56px 32px;max-width:1100px;margin:0 auto}
.section-header{display:flex;align-items:baseline;gap:12px;margin-bottom:32px}
.section-header h2{font-size:1.6rem;font-weight:700}
.section-header .count{font-size:0.85rem;color:var(--muted);background:var(--border);padding:3px 10px;border-radius:999px}
.product-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:20px}
.product-card{
  background:var(--surface);border-radius:var(--r);
  overflow:hidden;box-shadow:var(--shadow);
  border:1px solid var(--border);
  transition:transform .2s ease,box-shadow .2s ease;
}
.product-card:hover{transform:translateY(-4px);box-shadow:0 12px 32px rgba(0,0,0,0.13)}
.product-img{height:140px;display:grid;place-items:center}
.product-emoji{font-size:2.5rem}
.product-body{padding:16px}
.product-name{font-size:0.95rem;font-weight:600;margin-bottom:6px}
.product-price{color:var(--primary);font-weight:700;font-size:1rem;margin-bottom:6px}
.product-desc{font-size:0.8rem;color:var(--muted);line-height:1.5;margin-bottom:12px}
.btn-order{
  width:100%;padding:8px;background:var(--primary);color:#fff;
  border:none;border-radius:8px;font-size:0.83rem;font-weight:600;
  transition:opacity .18s;
}
.btn-order:hover{opacity:0.88}
.no-products{color:var(--muted);font-style:italic}

/* Footer */
footer{
  background:var(--primary);color:#fff;
  padding:40px 32px 24px;margin-top:40px;
}
.footer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:24px;max-width:900px;margin:0 auto 32px}
.footer-col h4{font-size:0.85rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;opacity:0.6;margin-bottom:12px}
.footer-col p,.footer-col a{font-size:0.88rem;opacity:0.85;line-height:1.8}
.footer-col a:hover{opacity:1;text-decoration:underline}
.social-links{display:flex;flex-wrap:wrap;gap:8px;margin-top:8px}
.social-link{
  display:flex;align-items:center;gap:6px;
  padding:6px 12px;border-radius:999px;
  background:rgba(255,255,255,0.12);color:#fff;
  font-size:0.8rem;font-weight:500;
  transition:background .18s;
}
.social-link:hover{background:rgba(255,255,255,0.22)}
.footer-bottom{text-align:center;font-size:0.75rem;opacity:0.45;border-top:1px solid rgba(255,255,255,0.15);padding-top:20px;max-width:900px;margin:0 auto}

/* ── Shared Table Styles ── */
.page-header{padding:32px 32px 0;max-width:1100px;margin:0 auto}
.page-header h2{font-size:1.5rem;font-weight:700;margin-bottom:4px}
.page-header p{color:var(--muted);font-size:0.88rem}
.page-content{padding:24px 32px;max-width:1100px;margin:0 auto}
.card{background:var(--surface);border-radius:var(--r);box-shadow:var(--shadow);border:1px solid var(--border);overflow:hidden;margin-bottom:24px}
.card-header{
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;
  padding:16px 20px;border-bottom:1px solid var(--border);background:var(--bg);
}
.card-header h3{font-size:0.95rem;font-weight:600}
.btn-primary{
  padding:8px 18px;background:var(--primary);color:#fff;
  border:none;border-radius:8px;font-size:0.83rem;font-weight:600;
  transition:opacity .18s;
}
.btn-primary:hover{opacity:0.88}
.btn-sm{
  padding:5px 12px;border-radius:6px;font-size:0.78rem;font-weight:500;
  border:1.5px solid var(--border);background:var(--surface);color:var(--text);
  cursor:pointer;transition:all .18s;
}
.btn-sm.danger{border-color:#FCA5A5;color:#DC2626}
.btn-sm.danger:hover{background:#DC2626;color:#fff;border-color:#DC2626}
.btn-sm.success{border-color:#86EFAC;color:#16A34A}
.btn-sm.success:hover{background:#16A34A;color:#fff;border-color:#16A34A}

.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:500px}
th{padding:12px 16px;text-align:left;font-size:0.78rem;font-weight:600;text-transform:uppercase;letter-spacing:0.5px;color:var(--muted);background:var(--bg);border-bottom:1px solid var(--border)}
td{padding:13px 16px;font-size:0.88rem;border-bottom:1px solid var(--border);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(0,0,0,0.015)}
.empty-row td{text-align:center;color:var(--muted);padding:32px;font-style:italic}

/* Status badges */
.badge{
  display:inline-flex;align-items:center;
  padding:3px 10px;border-radius:999px;font-size:0.75rem;font-weight:600;
}
.badge-pending   {background:#FEF3C7;color:#92400E}
.badge-processing{background:#DBEAFE;color:#1E40AF}
.badge-shipped   {background:#EDE9FE;color:#5B21B6}
.badge-done      {background:#DCFCE7;color:#14532D}
.badge-income    {background:#DCFCE7;color:#14532D}
.badge-expense   {background:#FEE2E2;color:#7F1D1D}

/* Low stock highlight */
.low-stock td:nth-child(3){color:#DC2626;font-weight:700}
.low-stock{background:rgba(239,68,68,0.04)}

/* Filter row */
.filter-row{display:flex;gap:8px;flex-wrap:wrap;padding:12px 20px;border-bottom:1px solid var(--border);background:var(--bg)}
.filter-btn{padding:5px 14px;border-radius:999px;border:1.5px solid var(--border);background:var(--surface);font-size:0.78rem;font-weight:500;color:var(--muted);cursor:pointer;transition:all .18s}
.filter-btn.active{background:var(--primary);border-color:var(--primary);color:#fff}

/* Balance strip */
.balance-strip{
  display:flex;gap:20px;flex-wrap:wrap;
  padding:20px;background:linear-gradient(135deg,var(--primary),color-mix(in srgb,var(--primary) 70%,#000));
  border-radius:var(--r);color:#fff;margin-bottom:20px;
  box-shadow:var(--shadow);
}
.balance-item{flex:1;min-width:120px}
.balance-label{font-size:0.72rem;font-weight:600;text-transform:uppercase;letter-spacing:0.8px;opacity:0.65;margin-bottom:4px}
.balance-value{font-family:'Poppins',sans-serif;font-size:1.4rem;font-weight:700}

/* Form inline */
.form-inline{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end}
.form-group{display:flex;flex-direction:column;gap:4px;flex:1;min-width:120px}
.form-group label{font-size:0.75rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:0.4px}
.form-group input,.form-group select{
  padding:8px 12px;border:1.5px solid var(--border);border-radius:8px;
  font-size:0.88rem;font-family:'Inter',sans-serif;outline:none;background:var(--surface);
  transition:border-color .18s;
}
.form-group input:focus,.form-group select:focus{border-color:var(--primary)}

/* Chart */
#accounting-chart-canvas{display:block;max-width:100%;margin:0 auto}

/* ── Keyframes ── */
@keyframes fadeIn{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}

/* ── Responsive ── */
@media(max-width:768px){
  nav{padding:10px 16px}
  .nav-links{display:none}
  .hamburger{display:flex}
  .section,.page-content,.page-header{padding-left:16px;padding-right:16px}
  #page-home .hero{padding:56px 16px}
  .balance-strip{gap:12px}
  footer{padding:32px 16px 20px}
}
@media(max-width:480px){
  .product-grid{grid-template-columns:1fr}
  .form-inline{flex-direction:column}
  .form-group{min-width:100%}
}
</style>
</head>
<body>

<!-- NAV -->
<nav id="main-nav">
  <div class="nav-brand">
    ${logoHTML}
    <span class="nav-store-name">${esc(storeName)}</span>
  </div>
  <div class="nav-links" id="nav-links">
    <a class="nav-link active" href="#" data-page="home" onclick="showPage('home',this);return false">🏠 Home</a>
    <a class="nav-link" href="#" data-page="orders" onclick="showPage('orders',this);return false">📦 Orders</a>
    <a class="nav-link" href="#" data-page="stock" onclick="showPage('stock',this);return false">🗃️ Stock</a>
    <a class="nav-link" href="#" data-page="accounting" onclick="showPage('accounting',this);return false">💰 Accounting</a>
  </div>
  <button class="hamburger" id="hamburger" aria-label="Menu" onclick="toggleMobileNav()">
    <span></span><span></span><span></span>
  </button>
</nav>
<div class="mobile-nav" id="mobile-nav">
  <a class="nav-link active" href="#" data-page="home" onclick="showPage('home',this);closeMobileNav();return false">🏠 Home</a>
  <a class="nav-link" href="#" data-page="orders" onclick="showPage('orders',this);closeMobileNav();return false">📦 Orders</a>
  <a class="nav-link" href="#" data-page="stock" onclick="showPage('stock',this);closeMobileNav();return false">🗃️ Stock</a>
  <a class="nav-link" href="#" data-page="accounting" onclick="showPage('accounting',this);closeMobileNav();return false">💰 Accounting</a>
</div>

<!-- ══ PAGE: HOME ══ -->
<div class="page active" id="page-home">
  <div class="hero">
    <div class="hero-logo">
      ${logoUrl ? `<img src="${logoUrl}" alt="${esc(storeName)}">` : initials}
    </div>
    <h1>${esc(storeName)}</h1>
    <p>${esc(tagline)}</p>
    <a href="#" class="btn-accent" onclick="showPage('orders',document.querySelector('[data-page=orders]'));return false">
      📦 View Orders
    </a>
  </div>

  <div class="section">
    <div class="section-header">
      <h2>Our Products</h2>
      <span class="count">${products.length} items</span>
    </div>
    <div class="product-grid">
      ${productCards}
    </div>
  </div>

  <footer>
    <div class="footer-grid">
      <div class="footer-col">
        <h4>Contact</h4>
        ${phone ? `<p>📞 ${esc(phone)}</p>` : ""}
        ${email ? `<p>✉️ <a href="mailto:${esc(email)}">${esc(email)}</a></p>` : ""}
        ${address ? `<p>📍 ${esc(address)}</p>` : ""}
      </div>
      <div class="footer-col">
        <h4>Follow Us</h4>
        <div class="social-links">${socialLinks || "<p>—</p>"}</div>
      </div>
    </div>
    <div class="footer-bottom">© ${new Date().getFullYear()} ${esc(storeName)}. Built with StoreBuilder.</div>
  </footer>
</div>

<!-- ══ PAGE: ORDERS ══ -->
<div class="page" id="page-orders">
  <div class="page-header">
    <h2>📦 Orders</h2>
    <p>Track and manage customer orders.</p>
  </div>
  <div class="page-content">
    <!-- Add Order Form -->
    <div class="card">
      <div class="card-header"><h3>New Order</h3></div>
      <div style="padding:16px 20px">
        <div class="form-inline" id="order-form">
          <div class="form-group">
            <label>Customer Name</label>
            <input id="o-customer" type="text" placeholder="John Doe">
          </div>
          <div class="form-group">
            <label>Product</label>
            <input id="o-product" type="text" placeholder="Product name">
          </div>
          <div class="form-group" style="max-width:90px">
            <label>Qty</label>
            <input id="o-qty" type="number" value="1" min="1">
          </div>
          <div class="form-group" style="max-width:140px">
            <label>Status</label>
            <select id="o-status">
              <option>Pending</option>
              <option>Processing</option>
              <option>Shipped</option>
              <option>Done</option>
            </select>
          </div>
          <div class="form-group" style="justify-content:flex-end;flex:none">
            <label>&nbsp;</label>
            <button class="btn-primary" onclick="addOrder()">＋ Add Order</button>
          </div>
        </div>
      </div>
    </div>

    <!-- Filter + Table -->
    <div class="card">
      <div class="filter-row" id="order-filters">
        <button class="filter-btn active" onclick="filterOrders('all',this)">All</button>
        <button class="filter-btn" onclick="filterOrders('Pending',this)">Pending</button>
        <button class="filter-btn" onclick="filterOrders('Processing',this)">Processing</button>
        <button class="filter-btn" onclick="filterOrders('Shipped',this)">Shipped</button>
        <button class="filter-btn" onclick="filterOrders('Done',this)">Done</button>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr><th>Order ID</th><th>Customer</th><th>Product</th><th>Qty</th><th>Status</th><th>Date</th><th>Actions</th></tr></thead>
          <tbody id="orders-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ══ PAGE: STOCK ══ -->
<div class="page" id="page-stock">
  <div class="page-header">
    <h2>🗃️ Stock / Inventory</h2>
    <p>Manage your product inventory.</p>
  </div>
  <div class="page-content">
    <div class="card">
      <div class="card-header">
        <h3>Add Product</h3>
      </div>
      <div style="padding:16px 20px">
        <div class="form-inline">
          <div class="form-group">
            <label>Product Name</label>
            <input id="s-name" type="text" placeholder="e.g. Batik Shirt">
          </div>
          <div class="form-group" style="max-width:120px">
            <label>SKU</label>
            <input id="s-sku" type="text" placeholder="SKU-001">
          </div>
          <div class="form-group" style="max-width:90px">
            <label>Stock Qty</label>
            <input id="s-qty" type="number" value="0" min="0">
          </div>
          <div class="form-group">
            <label>Price</label>
            <input id="s-price" type="text" placeholder="Rp 150.000">
          </div>
          <div class="form-group" style="max-width:90px">
            <label>Low Stock ≤</label>
            <input id="s-threshold" type="number" value="5" min="0">
          </div>
          <div class="form-group" style="justify-content:flex-end;flex:none">
            <label>&nbsp;</label>
            <button class="btn-primary" onclick="addStockItem()">＋ Add</button>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Product Name</th><th>SKU</th><th>Stock Qty</th><th>Price</th><th>Low Stock ≤</th><th>Last Updated</th><th>Actions</th></tr></thead>
          <tbody id="stock-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ══ PAGE: ACCOUNTING ══ -->
<div class="page" id="page-accounting">
  <div class="page-header">
    <h2>💰 Accounting</h2>
    <p>Track your income and expenses.</p>
  </div>
  <div class="page-content">
    <div class="balance-strip" id="balance-strip">
      <div class="balance-item"><div class="balance-label">Balance</div><div class="balance-value" id="bal-balance">Rp 0</div></div>
      <div class="balance-item"><div class="balance-label">Total Income</div><div class="balance-value" id="bal-income">Rp 0</div></div>
      <div class="balance-item"><div class="balance-label">Total Expenses</div><div class="balance-value" id="bal-expense">Rp 0</div></div>
    </div>

    <div class="card">
      <div class="card-header"><h3>Add Transaction</h3></div>
      <div style="padding:16px 20px">
        <div class="form-inline">
          <div class="form-group">
            <label>Description</label>
            <input id="a-desc" type="text" placeholder="e.g. Sold 5 shirts">
          </div>
          <div class="form-group" style="max-width:130px">
            <label>Type</label>
            <select id="a-type">
              <option>Income</option>
              <option>Expense</option>
            </select>
          </div>
          <div class="form-group" style="max-width:160px">
            <label>Amount (numbers only)</label>
            <input id="a-amount" type="number" placeholder="150000" min="0">
          </div>
          <div class="form-group" style="max-width:150px">
            <label>Date</label>
            <input id="a-date" type="date">
          </div>
          <div class="form-group" style="justify-content:flex-end;flex:none">
            <label>&nbsp;</label>
            <button class="btn-primary" onclick="addTransaction()">＋ Add</button>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h3>Monthly Overview</h3></div>
      <div style="padding:16px 20px">
        <canvas id="accounting-chart-canvas" height="180"></canvas>
      </div>
    </div>

    <div class="card">
      <div class="table-wrap">
        <table>
          <thead><tr><th>Date</th><th>Description</th><th>Type</th><th>Amount</th><th>Actions</th></tr></thead>
          <tbody id="acc-tbody"></tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- ══ DEPLOY MODAL ══ -->
<div id="sm-deploy-overlay" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);backdrop-filter:blur(6px);z-index:1000;display:none;place-items:center">
  <div style="background:#fff;border-radius:20px;padding:40px;width:min(480px,92vw);text-align:center;box-shadow:0 20px 60px rgba(0,0,0,0.25)">
    <span style="font-size:3rem;display:block;margin-bottom:16px">🚀</span>
    <h2 style="font-family:'Poppins',sans-serif;margin-bottom:8px">Coming Soon!</h2>
    <p style="color:#6B7280;line-height:1.6;margin-bottom:24px">We're working hard to bring one-click deployment. Join the waitlist and we'll notify you the moment it launches!</p>
    <div style="display:flex;gap:8px;margin-bottom:12px">
      <input id="sm-waitlist-email" type="email" placeholder="your@email.com" style="flex:1;padding:10px 14px;border:1.5px solid #E5E7F0;border-radius:999px;font-size:0.9rem;font-family:'Inter',sans-serif;outline:none">
      <button onclick="joinWaitlist()" style="padding:10px 18px;background:#5B6AF5;color:#fff;border:none;border-radius:999px;font-size:0.85rem;font-weight:600;font-family:'Inter',sans-serif;cursor:pointer">Notify Me</button>
    </div>
    <button onclick="document.getElementById('sm-deploy-overlay').style.display='none'" style="background:none;border:none;color:#9CA3AF;font-size:0.85rem;cursor:pointer;font-family:'Inter',sans-serif;text-decoration:underline">Close</button>
  </div>
</div>

<script>
// ── Utilities ──────────────────────────────────────────────
function $(id){ return document.getElementById(id); }
function fmt(n){ return 'Rp ' + Number(n).toLocaleString('id-ID'); }
function today(){ return new Date().toISOString().slice(0,10); }
function uid(){ return Date.now().toString(36) + Math.random().toString(36).slice(2,6); }

// ── Navigation ─────────────────────────────────────────────
function showPage(name, el){
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(a => a.classList.remove('active'));
  $('page-' + name).classList.add('active');
  document.querySelectorAll('[data-page="'+name+'"]').forEach(a => a.classList.add('active'));
  if(name === 'accounting') renderChart();
}
function toggleMobileNav(){
  $('hamburger').classList.toggle('open');
  $('mobile-nav').classList.toggle('open');
}
function closeMobileNav(){
  $('hamburger').classList.remove('open');
  $('mobile-nav').classList.remove('open');
}

// ── Orders ─────────────────────────────────────────────────
let orderFilter = 'all';
function getOrders(){ try{ return JSON.parse(localStorage.getItem('storebuilder_orders') || '[]'); }catch(e){return [];} }
function saveOrders(o){ localStorage.setItem('storebuilder_orders', JSON.stringify(o)); }

function addOrder(){
  const customer = $('o-customer').value.trim();
  const product  = $('o-product').value.trim();
  const qty      = parseInt($('o-qty').value) || 1;
  const status   = $('o-status').value;
  if(!customer || !product){ alert('Please fill in customer name and product.'); return; }
  const orders = getOrders();
  orders.unshift({ id: uid(), customer, product, qty, status, date: today() });
  saveOrders(orders);
  $('o-customer').value = ''; $('o-product').value = ''; $('o-qty').value = 1;
  renderOrders();
}

function openAddOrderPrefill(productName){
  showPage('orders', document.querySelector('[data-page="orders"]'));
  $('o-product').value = productName;
  $('o-customer').focus();
}

function updateOrderStatus(id, status){
  const orders = getOrders().map(o => o.id === id ? {...o, status} : o);
  saveOrders(orders); renderOrders();
}
function deleteOrder(id){
  if(!confirm('Delete this order?')) return;
  saveOrders(getOrders().filter(o => o.id !== id)); renderOrders();
}
function filterOrders(f, btn){
  orderFilter = f;
  document.querySelectorAll('#order-filters .filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderOrders();
}
function badgeClass(status){ return 'badge badge-' + status.toLowerCase().replace(' ','-'); }

function renderOrders(){
  const orders = getOrders().filter(o => orderFilter === 'all' || o.status === orderFilter);
  const tbody = $('orders-tbody');
  if(!orders.length){
    tbody.innerHTML = '<tr class="empty-row"><td colspan="7">No orders yet. Add your first order above!</td></tr>';
    return;
  }
  tbody.innerHTML = orders.map(o => \`
    <tr>
      <td><code style="font-size:0.75rem;color:#6B7280">\${o.id}</code></td>
      <td><strong>\${esc2(o.customer)}</strong></td>
      <td>\${esc2(o.product)}</td>
      <td>\${o.qty}</td>
      <td>
        <select class="\${badgeClass(o.status)}" onchange="updateOrderStatus('\${o.id}',this.value)" style="border:none;background:transparent;font-weight:600;font-size:0.75rem;cursor:pointer">
          \${['Pending','Processing','Shipped','Done'].map(s => \`<option \${s===o.status?'selected':''} value="\${s}">\${s}</option>\`).join('')}
        </select>
      </td>
      <td>\${o.date}</td>
      <td><button class="btn-sm danger" onclick="deleteOrder('\${o.id}')">Delete</button></td>
    </tr>\`).join('');
}

// ── Stock ──────────────────────────────────────────────────
function getStock(){ try{ return JSON.parse(localStorage.getItem('storebuilder_stock') || '[]'); }catch(e){return [];} }
function saveStock(s){ localStorage.setItem('storebuilder_stock', JSON.stringify(s)); }

function addStockItem(){
  const name = $('s-name').value.trim();
  if(!name){ alert('Product name is required.'); return; }
  const item = {
    id: uid(), name,
    sku: $('s-sku').value.trim() || ('SKU-' + Date.now().toString().slice(-4)),
    qty: parseInt($('s-qty').value) || 0,
    price: $('s-price').value.trim(),
    threshold: parseInt($('s-threshold').value) || 5,
    updated: today()
  };
  const stock = getStock(); stock.unshift(item); saveStock(stock);
  $('s-name').value = ''; $('s-sku').value = ''; $('s-qty').value = 0; $('s-price').value = '';
  renderStock();
}
function deleteStockItem(id){
  if(!confirm('Delete this product?')) return;
  saveStock(getStock().filter(s => s.id !== id)); renderStock();
}
function editStockQty(id){
  const item = getStock().find(s => s.id === id);
  if(!item) return;
  const newQty = prompt('New stock quantity for ' + item.name + ':', item.qty);
  if(newQty === null) return;
  const qty = parseInt(newQty);
  if(isNaN(qty)){ alert('Please enter a valid number.'); return; }
  saveStock(getStock().map(s => s.id === id ? {...s, qty, updated: today()} : s)); renderStock();
}
function renderStock(){
  const stock = getStock();
  const tbody = $('stock-tbody');
  if(!stock.length){
    tbody.innerHTML = '<tr class="empty-row"><td colspan="7">No products in stock. Add one above!</td></tr>';
    return;
  }
  tbody.innerHTML = stock.map(s => \`
    <tr class="\${s.qty <= s.threshold ? 'low-stock' : ''}">
      <td><strong>\${esc2(s.name)}</strong></td>
      <td><code style="font-size:0.78rem">\${esc2(s.sku)}</code></td>
      <td>\${s.qty} \${s.qty <= s.threshold ? '⚠️' : ''}</td>
      <td>\${esc2(s.price || '—')}</td>
      <td>\${s.threshold}</td>
      <td>\${s.updated}</td>
      <td style="display:flex;gap:6px;flex-wrap:wrap">
        <button class="btn-sm success" onclick="editStockQty('\${s.id}')">Edit Qty</button>
        <button class="btn-sm danger"  onclick="deleteStockItem('\${s.id}')">Delete</button>
      </td>
    </tr>\`).join('');
}

// ── Accounting ──────────────────────────────────────────────
function getAcc(){ try{ return JSON.parse(localStorage.getItem('storebuilder_accounting') || '[]'); }catch(e){return [];} }
function saveAcc(a){ localStorage.setItem('storebuilder_accounting', JSON.stringify(a)); }

function addTransaction(){
  const desc   = $('a-desc').value.trim();
  const type   = $('a-type').value;
  const amount = parseFloat($('a-amount').value);
  const date   = $('a-date').value || today();
  if(!desc || isNaN(amount) || amount <= 0){ alert('Please fill in description and a positive amount.'); return; }
  const acc = getAcc(); acc.unshift({ id: uid(), desc, type, amount, date });
  saveAcc(acc);
  $('a-desc').value = ''; $('a-amount').value = '';
  renderAcc(); renderChart();
}
function deleteTransaction(id){
  if(!confirm('Delete this transaction?')) return;
  saveAcc(getAcc().filter(a => a.id !== id)); renderAcc(); renderChart();
}
function renderAcc(){
  const acc = getAcc();
  let income = 0, expense = 0;
  acc.forEach(a => { if(a.type === 'Income') income += a.amount; else expense += a.amount; });
  $('bal-income').textContent  = fmt(income);
  $('bal-expense').textContent = fmt(expense);
  $('bal-balance').textContent = fmt(income - expense);

  const tbody = $('acc-tbody');
  if(!acc.length){
    tbody.innerHTML = '<tr class="empty-row"><td colspan="5">No transactions yet. Add your first entry above!</td></tr>';
    return;
  }
  tbody.innerHTML = acc.map(a => \`
    <tr>
      <td>\${a.date}</td>
      <td>\${esc2(a.desc)}</td>
      <td><span class="badge badge-\${a.type.toLowerCase()}">\${a.type}</span></td>
      <td style="font-weight:600;color:\${a.type==='Income'?'#16A34A':'#DC2626'}">\${a.type==='Income'?'+':'-'}\${fmt(a.amount)}</td>
      <td><button class="btn-sm danger" onclick="deleteTransaction('\${a.id}')">Delete</button></td>
    </tr>\`).join('');
}

function renderChart(){
  const canvas = $('accounting-chart-canvas');
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const acc = getAcc();

  // Group by YYYY-MM
  const monthly = {};
  acc.forEach(a => {
    const month = a.date.slice(0,7);
    if(!monthly[month]) monthly[month] = {income:0, expense:0};
    if(a.type==='Income') monthly[month].income += a.amount;
    else monthly[month].expense += a.amount;
  });
  const keys = Object.keys(monthly).sort().slice(-6); // last 6 months

  const W = canvas.offsetWidth || 600;
  canvas.width = W; canvas.height = 180;
  ctx.clearRect(0,0,W,180);

  if(!keys.length){
    ctx.fillStyle = '#9CA3AF';
    ctx.font = '14px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('No data yet — add transactions to see the chart', W/2, 90);
    return;
  }

  const maxVal = Math.max(...keys.flatMap(k => [monthly[k].income, monthly[k].expense]), 1);
  const pad = 40, barW = Math.min(40, (W - pad*2) / (keys.length * 2.5));
  const gap = (W - pad*2 - keys.length * barW * 2) / (keys.length + 1);
  const chartH = 140;

  keys.forEach((k, i) => {
    const x = pad + gap * (i+1) + i * barW * 2;
    const { income, expense } = monthly[k];

    // Income bar
    const ih = (income / maxVal) * chartH;
    ctx.fillStyle = '#4ADE80';
    ctx.beginPath();
    ctx.roundRect(x, chartH - ih + 10, barW, ih, [4,4,0,0]);
    ctx.fill();

    // Expense bar
    const eh = (expense / maxVal) * chartH;
    ctx.fillStyle = '#F87171';
    ctx.beginPath();
    ctx.roundRect(x + barW + 2, chartH - eh + 10, barW, eh, [4,4,0,0]);
    ctx.fill();

    // Label
    ctx.fillStyle = '#6B7280';
    ctx.font = '10px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(k.slice(5), x + barW, 168);
  });

  // Legend
  ctx.fillStyle = '#4ADE80'; ctx.fillRect(W-120, 4, 12, 12);
  ctx.fillStyle = '#374151'; ctx.font = '11px Inter,sans-serif'; ctx.textAlign = 'left';
  ctx.fillText('Income', W-104, 14);
  ctx.fillStyle = '#F87171'; ctx.fillRect(W-120, 20, 12, 12);
  ctx.fillStyle = '#374151'; ctx.fillText('Expense', W-104, 30);
}

// ── Waitlist ───────────────────────────────────────────────
function joinWaitlist(){
  const email = $('sm-waitlist-email').value.trim();
  if(!email){ alert('Please enter your email.'); return; }
  alert('✅ Thanks! We\\'ll notify you at ' + email + ' when deployment launches.');
  $('sm-deploy-overlay').style.display = 'none';
}

// ── XSS helper ────────────────────────────────────────────
function esc2(s){ const d=document.createElement('div'); d.textContent=String(s||''); return d.innerHTML; }

// ── Init ──────────────────────────────────────────────────
(function(){
  $('a-date').value = today();
  renderOrders(); renderStock(); renderAcc();
  window.addEventListener('resize', () => { if($('page-accounting').classList.contains('active')) renderChart(); });
})();
</script>
</body>
</html>`;
}

// ── XSS escape (used during template build, not in generated site JS) ──
function esc(s) {
  return String(s || "")
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#39;");
}
