// template-engine.js
// Generates a complete, self-contained HTML site string from storeData.

// storeData shape:
// {
//   storeName, tagline, products: [{name, price, description}],
//   primaryColor, accentColor,
//   logoDataUrl (base64 or ""),
//   contact: {phone, email, address},
//   social: {instagram, whatsapp, tiktok}
// }

function generateSite(storeData) {
  switch (storeData.templateName) {
    case "Dashboard Modern":
      return dashboardModernTemplate(storeData);
    case "Laporan Sederhana":
      return laporanSederhanaTemplate(storeData);
    case "Toko Klasik":
    default:
      return tokoKlasikTemplate(storeData);
  }
}
