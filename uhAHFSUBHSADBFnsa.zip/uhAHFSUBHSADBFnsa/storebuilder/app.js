// app.js — UsahaKu Dashboard — 4-Phase State Machine
// API keys live ONLY in .env on the server — never in the browser.
// Gemini calls are proxied through /api/gemini.
// Firebase is initialised from /api/config (public Firebase config).

"use strict";

// ── Approve keywords (case-insensitive) ────────────────────────────────────
const APPROVE_WORDS = new Set([
  "approve", "approved", "setuju", "ok", "oke",
  "yes", "ya", "lanjut", "next", "confirm",
]);

// ── App State ──────────────────────────────────────────────────────────────
let db               = null;  // Firestore instance — null if not configured
let phase            = 1;
let productList      = [];    // [{name, price}]
let storeName        = "";
let tagline          = "";
let selectedTemplate = null;
let selectedColors   = {};
let generatedHTML    = "";

// ── DOM Cache ──────────────────────────────────────────────────────────────
let views, msg1, msg2, input1, input2, send1, send2;
let productTbody, approveBtn, generateBtn, previewIframe, deployModal;

// ── Boot ───────────────────────────────────────────────────────────────────
window.addEventListener("DOMContentLoaded", async () => {
  // DOM refs
  views        = { 1: document.getElementById("view-1"), 2: document.getElementById("view-2"), 3: document.getElementById("view-3"), 4: document.getElementById("view-4") };
  msg1         = document.getElementById("msg-1");
  input1       = document.getElementById("input-1");
  send1        = document.getElementById("send-1");
  msg2         = document.getElementById("msg-2");
  input2       = document.getElementById("input-2");
  send2        = document.getElementById("send-2");
  productTbody = document.getElementById("product-tbody");
  approveBtn   = document.getElementById("approve-btn");
  generateBtn  = document.getElementById("generate-btn");
  previewIframe = document.getElementById("preview-iframe");
  deployModal  = document.getElementById("deploy-modal");

  // Event wiring
  send1.addEventListener("click", handlePhase1Send);
  input1.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handlePhase1Send(); } });

  send2.addEventListener("click", handlePhase2Send);
  input2.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handlePhase2Send(); } });

  approveBtn.addEventListener("click", () => {
    appendMsg(msg2, "user", "approve");
    transitionToPhase3();
  });

  generateBtn.addEventListener("click", handleGenerate);

  document.getElementById("example-btn")?.addEventListener("click", () => {
    input1.value = "Saya jual Baju Batik Rp 150.000, Tas Kulit Rp 350.000, dan Sendal Anyaman Rp 75.000. Toko saya namanya Toko Maju Jaya.";
    input1.focus();
  });

  document.querySelectorAll(".skeleton-card").forEach(card => {
    card.addEventListener("click", () => selectTemplate(card));
  });

  document.getElementById("copy-html-btn")?.addEventListener("click", copyHTML);
  document.getElementById("deploy-btn")?.addEventListener("click", openDeployModal);
  document.getElementById("restart-btn")?.addEventListener("click", () => location.reload());

  // Init: check server + initialise Firebase in parallel
  await Promise.all([checkServer(), initFirebase()]);

  // Show initial greeting
  appendMsg(msg1, "bot", "Halo! Saya akan membantu kamu membuat website toko. <strong>Ceritakan produk apa saja yang kamu jual beserta harganya.</strong><br>Kamu bisa menyebut banyak produk sekaligus! 🛍️");
});

// ── Server Health Check ────────────────────────────────────────────────────
async function checkServer() {
  try {
    const res = await fetch("/api/config");
    if (!res.ok) throw new Error("bad status");
    // Server is running — keys are managed in .env, nothing to check in the browser
  } catch {
    showBanner("Server tidak dapat dijangkau. Pastikan <code>server.py</code> sedang berjalan lalu reload.");
    setInputDisabled(true);
  }
}

function showBanner(html) {
  const el = document.getElementById("api-warning");
  el.querySelector("span:last-child").innerHTML = html;
  el.classList.remove("hidden");
  el.classList.add("flex");
}

function setInputDisabled(disabled) {
  [input1, send1].forEach(el => {
    el.disabled = disabled;
    el.classList.toggle("opacity-50", disabled);
    el.classList.toggle("cursor-not-allowed", disabled);
  });
}

// ── Firebase Initialisation ────────────────────────────────────────────────
async function initFirebase() {
  try {
    const res = await fetch("/api/config");
    if (!res.ok) return;
    const cfg = await res.json();

    if (cfg.firebaseReady && typeof firebase !== "undefined") {
      if (!firebase.apps.length) {
        firebase.initializeApp(cfg.firebase);
      }
      db = firebase.firestore();
      console.log("[UsahaKu] Firestore connected — session:", getSessionId());
    } else {
      console.warn("[UsahaKu] Firebase not configured in .env — sessions won't persist across reloads");
    }
  } catch (err) {
    console.warn("[UsahaKu] Firebase init skipped:", err.message);
  }
}

// ── Session Identity ───────────────────────────────────────────────────────
function getSessionId() {
  let id = localStorage.getItem("usahaku_session_id");
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem("usahaku_session_id", id);
  }
  return id;
}

// ── Firestore — Database Schema ────────────────────────────────────────────
//
//  sessions/{sessionId}
//    ├── storeName        : string
//    ├── tagline          : string
//    ├── selectedTemplate : string
//    ├── primaryColor     : string
//    ├── accentColor      : string
//    ├── phase            : number  (1-4)
//    ├── updatedAt        : Timestamp
//    │
//    ├── products/{productId}
//    │     ├── name       : string
//    │     ├── price      : string
//    │     ├── description: string
//    │     ├── order      : number
//    │     └── createdAt  : Timestamp
//    │
//    └── chat_history/{messageId}
//          ├── role       : "user" | "bot"
//          ├── content    : string
//          ├── step       : number  (1-3)
//          └── timestamp  : Timestamp

async function dbSaveSession(data) {
  if (!db) return;
  try {
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    await db.collection("sessions").doc(getSessionId()).set(
      { ...data, sessionId: getSessionId(), updatedAt: ts },
      { merge: true }
    );
  } catch (e) { console.warn("[Firestore] saveSession:", e.message); }
}

async function dbSaveChatMessage(role, content, step) {
  if (!db) return;
  try {
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    await db.collection("sessions").doc(getSessionId())
      .collection("chat_history").add({ role, content, step, timestamp: ts });
  } catch (e) { console.warn("[Firestore] saveChatMessage:", e.message); }
}

async function dbSaveProducts(products) {
  if (!db) return;
  try {
    const colRef = db.collection("sessions").doc(getSessionId()).collection("products");
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    // Bulk add — order index preserved
    for (const [i, p] of products.entries()) {
      await colRef.add({ ...p, order: i, createdAt: ts });
    }
  } catch (e) { console.warn("[Firestore] saveProducts:", e.message); }
}

// ── Phase Management ───────────────────────────────────────────────────────
function showView(n) {
  Object.entries(views).forEach(([k, el]) => el.classList.toggle("active", +k === n));
  phase = n;
  window.scrollTo({ top: 0, behavior: "smooth" });
}

// ── Phase 1 — First message → product extraction ──────────────────────────
async function handlePhase1Send() {
  const text = input1.value.trim();
  if (!text) return;
  input1.value = "";
  setInputDisabled(true);

  appendMsg(msg1, "user", text);
  dbSaveChatMessage("user", text, 1);

  const typId = showTyping(msg1);
  try {
    const result = await extractProducts(text);
    removeTyping(typId);

    if (!result.products || result.products.length === 0) {
      const retry = "Hmm, aku belum bisa menemukan daftar produk. Bisa sebutkan nama dan harga produknya lebih jelas? Contoh: <strong>\"Baju Batik Rp 150.000, Tas Kulit Rp 350.000\"</strong>";
      appendMsg(msg1, "bot", retry);
      dbSaveChatMessage("bot", retry, 1);
      setInputDisabled(false);
      input1.focus();
      return;
    }

    productList = result.products;
    storeName   = result.storeName || "Toko Kita";
    tagline     = result.tagline   || "";

    const successMsg = `Sip! Ditemukan <strong>${productList.length} produk</strong>. Cek daftar di bawah — revisi via chat jika ada yang perlu diubah, lalu ketik <strong>"approve"</strong> untuk lanjut! ✅`;
    appendMsg(msg1, "bot", successMsg);
    dbSaveChatMessage("bot", successMsg, 1);

    // Fire-and-forget — never let a DB call block the UI transition
    dbSaveSession({ storeName, tagline, phase: 2 });
    dbSaveProducts(productList);

    await sleep(400);

    // Mirror phase-1 messages into phase-2 chat
    msg1.querySelectorAll(".chat-row").forEach(row => msg2.appendChild(row.cloneNode(true)));

    // Populate table and switch view
    renderProductTable();
    input2.disabled = false;  // ensure input is active before transition
    send2.disabled  = false;
    showView(2);
    input2.focus();

  } catch (err) {
    removeTyping(typId);
    appendMsg(msg1, "bot", `⚠️ Terjadi kesalahan: <strong>${esc(toErrMsg(err))}</strong>`);
    setInputDisabled(false); // let user retry
  }
}

// ── Phase 2 — Revision or approve ─────────────────────────────────────────
async function handlePhase2Send() {
  const text = input2.value.trim();
  if (!text) return;
  input2.value = "";

  const lower = text.toLowerCase().trim();
  appendMsg(msg2, "user", text);
  dbSaveChatMessage("user", text, 2);

  if (APPROVE_WORDS.has(lower)) {
    await sleep(200);
    const approveMsg = "Produk telah dikonfirmasi! 🎉 Sekarang pilih tampilan website tokomu.";
    appendMsg(msg2, "bot", approveMsg);
    dbSaveChatMessage("bot", approveMsg, 2);
    dbSaveSession({ phase: 3 });
    await sleep(500);
    transitionToPhase3();
    return;
  }

  input2.disabled = true;
  send2.disabled  = true;

  const typId = showTyping(msg2);
  try {
    const updated = await reviseProducts(productList, text);
    removeTyping(typId);

    productList = updated;
    renderProductTable();

    const revMsg = "Daftar produk sudah diperbarui! Cek kembali di bawah. Ketik <strong>\"approve\"</strong> jika sudah benar.";
    appendMsg(msg2, "bot", revMsg);
    dbSaveChatMessage("bot", revMsg, 2);
    dbSaveProducts(productList);

  } catch (err) {
    removeTyping(typId);
    appendMsg(msg2, "bot", `⚠️ Gagal merevisi: ${esc(toErrMsg(err))}`);
  } finally {
    input2.disabled = false;
    send2.disabled  = false;
    input2.focus();
  }
}

function transitionToPhase3() { showView(3); }

// ── Phase 3 — Template selection + generate ───────────────────────────────
function selectTemplate(card) {
  document.querySelectorAll(".skeleton-card").forEach(c => {
    c.classList.remove("selected");
    c.querySelector(".check-icon").style.opacity = "0";
  });
  card.classList.add("selected");
  card.querySelector(".check-icon").style.opacity = "1";
  selectedTemplate = card.dataset.template;
  selectedColors   = { primaryColor: card.dataset.primary || "#2C3E50", accentColor: card.dataset.accent || "#E67E22" };
  document.getElementById("no-template-msg").classList.add("hidden");
}

async function handleGenerate() {
  if (!selectedTemplate) {
    document.getElementById("no-template-msg").classList.remove("hidden");
    return;
  }
  generateBtn.disabled = true;
  generateBtn.innerHTML = `<span class="material-symbols-outlined animate-spin" style="font-size:20px">progress_activity</span>&nbsp; Membuat website...`;

  try {
    const fullData = await buildStoreData();
    fullData.templateName = selectedTemplate;
    generatedHTML = generateSite(fullData);

    dbSaveSession({ selectedTemplate, primaryColor: selectedColors.primaryColor, accentColor: selectedColors.accentColor, phase: 4 });

    showView(4);
    previewIframe.srcdoc = generatedHTML;
  } catch (err) {
    alert(`Gagal membuat website: ${toErrMsg(err)}`);
    generateBtn.disabled = false;
    generateBtn.innerHTML = `<span class="material-symbols-outlined msf" style="font-size:21px">auto_awesome</span>&nbsp; Buat Website Sekarang`;
  }
}

// ── Gemini Proxy Calls ─────────────────────────────────────────────────────
// All API calls go through /api/gemini on the Flask server.
// The Gemini key lives ONLY in .env — never in the browser.

async function callGemini(prompt) {
  const res = await fetch("/api/gemini", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
  });

  if (!res.ok) {
    // Gemini errors: { error: { code, message, status } }
    // Server errors: { error: "string" }
    const body = await res.json().catch(() => ({}));
    const geminiErr = body?.error;
    const msg = typeof geminiErr === "string"
      ? geminiErr
      : (geminiErr?.message || JSON.stringify(geminiErr) || `HTTP ${res.status}`);
    throw new Error(msg);
  }

  const data = await res.json();
  let raw = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
  // Strip markdown code fences if Gemini wraps the JSON
  raw = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "").trim();
  return raw;
}

async function extractProducts(userText) {
  const prompt = `Extract products and store info from the user's text.
Return ONLY a valid JSON object:
{
  "storeName": "name of the store ('Toko Kita' if not mentioned)",
  "tagline": "a catchy short tagline in Indonesian",
  "products": [
    { "name": "product name", "price": "price as written, e.g. Rp 150.000, or empty string" }
  ]
}

User text: "${userText}"
Rules: extract ALL products, preserve prices exactly, return ONLY JSON.`;

  return JSON.parse(await callGemini(prompt));
}

async function reviseProducts(currentList, revisionText) {
  const prompt = `Current product list:
${JSON.stringify(currentList, null, 2)}

User revision: "${revisionText}"

Return ONLY the updated list as a JSON array:
[{"name":"...","price":"..."}]
Rules: apply exactly what the user asked, return ONLY JSON.`;

  return JSON.parse(await callGemini(prompt));
}

async function buildStoreData() {
  const prompt = `Generate complete store data JSON for website generation.

Store name: ${storeName}
Tagline: ${tagline}
Products: ${JSON.stringify(productList)}
Template style: ${selectedTemplate}
Primary color: ${selectedColors.primaryColor}
Accent color: ${selectedColors.accentColor}

Return ONLY:
{
  "storeName": "...",
  "tagline": "...",
  "products": [{"name":"...","price":"...","description":"short Indonesian description"}],
  "primaryColor": "${selectedColors.primaryColor}",
  "accentColor": "${selectedColors.accentColor}",
  "logoDataUrl": "",
  "contact": {"phone":"","email":"","address":""},
  "social": {"instagram":"","whatsapp":"","tiktok":""}
}`;

  return JSON.parse(await callGemini(prompt));
}

// ── Product Table ──────────────────────────────────────────────────────────
function renderProductTable() {
  if (!productTbody) return;
  if (productList.length === 0) {
    productTbody.innerHTML = `<tr><td colspan="3" class="px-6 py-10 text-center text-on-surface-variant text-sm italic">Belum ada produk. Ceritakan produkmu di chat!</td></tr>`;
    return;
  }
  productTbody.innerHTML = productList.map((p, i) => `
    <tr class="hover:bg-surface-container-low/60">
      <td class="px-6 py-4 text-on-surface-variant text-sm">${i + 1}</td>
      <td class="px-6 py-4">
        <div class="flex items-center gap-2">
          <div class="w-1.5 h-1.5 rounded-full bg-primary flex-shrink-0"></div>
          <span class="font-medium text-sm text-on-surface">${esc(p.name || "—")}</span>
        </div>
      </td>
      <td class="px-6 py-4 text-right">
        <span class="font-bold text-sm text-primary">${esc(p.price || "—")}</span>
      </td>
    </tr>`).join("");
}

// ── Chat Helpers ───────────────────────────────────────────────────────────
function appendMsg(container, role, html) {
  const isBot = role === "bot";
  const row = document.createElement("div");
  row.className = `chat-row flex gap-2.5 bubble-in${isBot ? "" : " flex-row-reverse"}`;
  row.innerHTML = isBot
    ? `<div class="w-7 h-7 rounded-full bg-primary flex items-center justify-center flex-shrink-0 shadow-sm"><span class="material-symbols-outlined text-white msf" style="font-size:13px">bolt</span></div>
       <div class="bg-surface-container text-on-surface px-4 py-2.5 rounded-2xl rounded-tl-none border border-outline-variant/30 text-sm leading-relaxed max-w-[88%]">${html}</div>`
    : `<div class="w-7 h-7 rounded-full bg-secondary flex items-center justify-center flex-shrink-0 shadow-sm"><span class="material-symbols-outlined text-white msf" style="font-size:13px">person</span></div>
       <div class="bg-primary-container text-on-primary px-4 py-2.5 rounded-2xl rounded-tr-none text-sm leading-relaxed max-w-[88%]">${esc(html)}</div>`;
  container.appendChild(row);
  container.scrollTop = container.scrollHeight;
}

function showTyping(container) {
  const id = "typ-" + Date.now();
  const el = document.createElement("div");
  el.id = id;
  el.className = "chat-row flex gap-2.5 bubble-in";
  el.innerHTML = `<div class="w-7 h-7 rounded-full bg-primary flex items-center justify-center flex-shrink-0 shadow-sm"><span class="material-symbols-outlined text-white msf" style="font-size:13px">bolt</span></div>
    <div class="bg-surface-container px-4 py-3 rounded-2xl rounded-tl-none border border-outline-variant/30">
      <div class="flex gap-1 items-center">
        <div class="w-2 h-2 rounded-full bg-primary/50 dot-1"></div>
        <div class="w-2 h-2 rounded-full bg-primary/50 dot-2"></div>
        <div class="w-2 h-2 rounded-full bg-primary/50 dot-3"></div>
      </div>
    </div>`;
  container.appendChild(el);
  container.scrollTop = container.scrollHeight;
  return id;
}

function removeTyping(id) { document.getElementById(id)?.remove(); }

// ── Copy HTML ──────────────────────────────────────────────────────────────
async function copyHTML() {
  if (!generatedHTML) return;
  try {
    await navigator.clipboard.writeText(generatedHTML);
    const btn = document.getElementById("copy-html-btn");
    const orig = btn.textContent;
    btn.textContent = "Tersalin!";
    setTimeout(() => { btn.textContent = orig; }, 2000);
  } catch {
    console.log("Generated HTML:\n", generatedHTML);
    alert("Clipboard tidak tersedia. HTML telah di-log ke browser console.");
  }
}

// ── Deploy Modal ───────────────────────────────────────────────────────────
function openDeployModal()  { deployModal.style.display = "grid"; }
function closeDeployModal() { deployModal.style.display = "none"; }
function joinWaitlist() {
  const email = document.getElementById("waitlist-email").value.trim();
  if (!email) { alert("Masukkan email kamu."); return; }
  const btn = document.getElementById("waitlist-email").nextElementSibling;
  btn.textContent = "Terdaftar!";
  btn.disabled = true;
  setTimeout(() => closeDeployModal(), 1800);
}

// ── Utilities ──────────────────────────────────────────────────────────────
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
function esc(s) {
  return String(s || "")
    .replace(/&/g,"&amp;").replace(/</g,"&lt;")
    .replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;");
}
/** Safely convert any thrown value to a readable string. */
function toErrMsg(err) {
  if (!err) return "Unknown error";
  if (typeof err === "string") return err;
  if (typeof err.message === "string") return err.message || "Unknown error";
  return JSON.stringify(err);
}
