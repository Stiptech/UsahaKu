# 🛍️ StoreBuilder

> AI-powered website generator for non-technical store owners. Build a professional business website through a friendly chat — powered by Google Gemini.

---

## Quick Start

### 1. Get a free Gemini API key
Visit [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey) and create a free key.

### 2. Set your API key
Open `config.js` and replace `YOUR_API_KEY_HERE` with your key:

```js
const CONFIG = {
  GEMINI_API_KEY: "AIzaSy..."   // ← paste here
};
```

### 3. Open the app
Open `index.html` in any modern browser (Chrome, Firefox, Edge, Safari).

> ⚠️ No server or build step needed — it runs entirely in your browser.

---

## How It Works

1. **Chat** — Answer 6 guided questions about your store
2. **AI extracts** — Gemini processes your answers into structured data
3. **Preview** — Your full website appears in-browser instantly
4. **Export** — Click "Copy HTML" to get a self-contained HTML file you can host anywhere

---

## Generated Website Features

The generated site is a **single self-contained HTML file** with four pages:

| Page | Features |
|------|----------|
| 🏠 **Home** | Hero section, product grid, contact footer, social links |
| 📦 **Orders** | Add/update/delete orders, status filter, `localStorage` persistence |
| 🗃️ **Stock** | Add/edit/delete inventory, low-stock highlighting |
| 💰 **Accounting** | Income/expense tracker, running balance, monthly bar chart |

All data is stored in `localStorage` — no backend required.

---

## File Structure

```
storebuilder/
├── config.js              ← ⚠️ Add your API key here (gitignored)
├── .gitignore
├── index.html             ← Open this in your browser
├── style.css              ← Design system
├── app.js                 ← Chat flow + Gemini API
├── template-engine.js     ← Site generator
└── templates/
    └── minimal.js         ← The Minimal/Clean site template
```

---

## Security

- `config.js` is listed in `.gitignore` — never commit it with a real key.
- The Gemini API key is only sent directly to Google's API — it never goes to any other server.

---

## MVP Scope

| Feature | Status |
|---------|--------|
| Guided chat onboarding | ✅ |
| Gemini API extraction | ✅ |
| Minimal/Clean theme | ✅ |
| Orders page (localStorage) | ✅ |
| Stock page (localStorage) | ✅ |
| Accounting page (localStorage) | ✅ |
| In-browser preview | ✅ |
| Price tag + Deploy button | ✅ |
| Real deployment | 🔜 Coming soon |
| Multiple themes | 🔜 Future |
| User accounts | 🔜 Future |
